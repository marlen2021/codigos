import os
os.system('cls')  # windows
#os.system('clear') # linux o os x
import calendar

from datetime import date, datetime

#Definición de variables
total_llamadas_altas = 0
total_llamadas_normales = 0
total_llamadas_bajas = 0
total_llamadas_registradas = 0

#Definición de listas
cedula_empleado = []
nombres_empleado = []
apellidos_empleado = []
edad_empleado = []
sexo_empleado = []
datos_empleado = []
documento_cliente = []
nombre_cliente = []
codigo_empleado = []
registro_llamadas = []
tipo_llamada = []
calidad_llamada = []
porcentaje = []
lista_fecha_llamada = []

#Definición de funciones
def calcular_edad(fecha_nacimiento):

    fecha_actual = date.today()
    resultado = fecha_actual.year - fecha_nacimiento.year
    resultado -= ((fecha_actual.month, fecha_actual.day) < (fecha_nacimiento.month, fecha_nacimiento.day))
    return resultado

def informe_revision():

    total_llamadas_registradas = len(calidad_llamada)
    print('La cantidad de llamadas registradas fue: ', total_llamadas_registradas)

    total_llamadas_altas = calidad_llamada.count('A') #altas
    total_llamadas_normales = calidad_llamada.count('M') #normales
    total_llamadas_bajas = calidad_llamada.count('B') #bajas
    print('La cantidad de llamadas registradas altas fue: ', total_llamadas_altas)
    print('La cantidad de llamadas registradas medias fue: ', total_llamadas_normales)
    print('La cantidad de llamadas registradas bajas fue: ', total_llamadas_bajas)

def ingresar_empleado():

    print('Ha seleccionado ingresar')
    cedula_empleado.append(input('Ingrese número de cédula empleado: '))
    nombres_empleado.append(input('Ingrese nombre Empleado: '))
    apellidos_empleado.append(input('Ingrese apellidos Empleado: '))
    sexo_empleado.append(input('Ingrese sexo Empleado (M/F): '))
    anio_nacimiento = int(input('Ingrese año de nacimiento(AAAA): '))
    mes_nacimiento = int(input('Ingrese mes de nacimiento(MM): '))
    dia_nacimiento = int(input('Ingrese año de nacimiento(DD): '))
    fecha_nacimiento_usuario = date(anio_nacimiento, mes_nacimiento, dia_nacimiento)
    edad = calcular_edad(fecha_nacimiento_usuario)
    edad_empleado.append(edad)

    print('Empleado agregado correctamente')
        
    agregar_empleado =str(input('Desea ingresar otro empleado (SI/NO):'))
    agregar_empleado = agregar_empleado.strip().upper()
    print(agregar_empleado)

    if agregar_empleado == 'SI':
        ingresar_empleado()
        
    else:
        ingresar()
        
        
def ingresar_llamada():

    codigo_empleado.append(input("Ingrese código empleado: "))
    fecha_llamada=input('Ingrese Fecha de Llamada "dd-mm-aaaa": ')
    #Usando la libreria para convertir el string ingresado a formato de fecha
    lista_fecha_llamada.append(datetime.strptime(fecha_llamada, '%d-%m-%Y'))  
    documento_cliente.append(input("Ingrese Documento Cliente: "))
    nombre_cliente.append(input("Ingrese Nombre Cliente: "))
    print('**********************************\n')
    print('Tipo de Llamada: ')
    print('**********************************\n') 
    print('Soporte: (S)')
    print('Servicio al Cliente: (SS)')
    print('Facturación: (F)')   

    tipo_llamada.append(str(input("Ingrese Tipo de Llamada: ")))

    print('**********************************\n')
    print('Nivel de Satisfacción: ')
    print('**********************************\n') 
    print('Alta: (A)')
    print('Media: (M)')
    print('Baja: (B)')
    valoracion_llamada = str(input('Ingrese calidad de la llamada: '))
    valoracion_llamada= valoracion_llamada.strip()
    valoracion_llamada = valoracion_llamada.upper()
    calidad_llamada.append(valoracion_llamada)
    porcentaje.append(valoracion_llamada)

    registro_llamadas = list(zip(codigo_empleado, documento_cliente, nombre_cliente, tipo_llamada, calidad_llamada, porcentaje))
    
    print('Llamada registrada correctamente')
        
    agregar_llamada =str(input('Desea ingresar otro llamada (SI/NO): '))
    agregar_llamada = agregar_llamada.strip().upper()
    #agregar_empleado = agregar_empleado.upper()
    
    if agregar_llamada == 'SI':
        ingresar_llamada()
        
    else:
        ingresar()


#Listas sobre listas con la informacion que ya existe
def registroMatriz():
    
    columna=1
    filas=len(lista_fecha_llamada)
    matriz=[]
    for i in range(filas):
        matriz.append([])
        for j in range(columna):
            matriz[i].append(lista_fecha_llamada[i].date())
            matriz[i].append(nombres_empleado[i])
            matriz[i].append(edad_empleado[i])
            matriz[i].append(sexo_empleado[i])

    return matriz


def ordenarRegistro(matriz):

    n=len(matriz)
    #Crear una nueva lista sin ningun valor, para poderla llenar
    matrizOrdenada=[None]*(n+1)
    for i in range(1, n+1, 1):
        #Recorrido
        matrizOrdenada[i]=matriz[i-1]
    
    for i in range(1,n,1):
        for j in range (i+1, n+1, 1):
            if matrizOrdenada[j][0]>matrizOrdenada[i][0]:
                x=matrizOrdenada[i]
                #Cambiando los valores de acuerdo a la comparación
                matrizOrdenada[i]=matrizOrdenada[j]
                matrizOrdenada[j]=x
    return matrizOrdenada

def leerArchivo(nombreArchivo):

    try:
        abrirArchivo=open("C:/Users/lccañon/Desktop/python_G45/"+nombreArchivo+".txt", "r", encoding="utf")
    except:
        print("El archivo", nombreArchivo, "no se puede abrir")
        quit
    return abrirArchivo.read()

def infoLlamada():

    info=[]
    matriz=registroMatriz()
    info=ordenarRegistro(matriz)

    n=len(registroMatriz())
    for i in range(1, n+1, 1):
        print(f"{info[i][0].day}-{info[i][0].month}-{info[i][0].year}-EMPLEADO({info[i][1]})-EDAD({info[i][2]})-SEXO({info[i][3]})")


def porcentaje_llamada ():

    porcentaje_total_altas = porcentaje.count("A")*2/100
    porcentaje_total_medias = porcentaje.count("M")*1/100
    porcentaje_total_bajas = porcentaje.count("B")
    print("Porcentaje Llamdas Altas",porcentaje_total_altas)
    print("Porcentaje Llamdas Medias",porcentaje_total_medias)
    print("Porcentaje Llamdas Bajas",porcentaje_total_bajas)

  
def ingresar():

    try:
        print('**********************************\n')
        print('Registro Aerolinea Avizpao ✈\n')
        print('**********************************\n')
        print('1. Ingresar empleado\n')
        print('2. Ingresar llamada\n')
        print('3. Regresar menú principal\n')

        opcion = int(input('Elige una opción: '))

    except ValueError:
            print('Oops!  Este número no es válido.  Intenta nuevamente...')

    if opcion == 1:
        ingresar_empleado()            
        main()
            
    elif opcion == 2:
        ingresar_llamada()
        main()
    
    elif opcion == 3:
        main()

    else:
            print('El valor ingresado no es válido')

def consultar_empleados():

    datos_empleado = list(zip(nombres_empleado, apellidos_empleado, sexo_empleado, edad_empleado))
    for i in datos_empleado:
        print(i)
    
def consultar_llamadas():

    registro_llamadas = list(zip(codigo_empleado, documento_cliente, nombre_cliente, tipo_llamada, calidad_llamada, porcentaje))
    for i in registro_llamadas:
        print(i)

def consultar():
    
    try:

        print('**********************************\n')
        print('Bienvenidos a la Aerolinea Avizpao ✈\n')
        print('**********************************\n')
        print('1. Empleados\n')
        print('2. Llamadas\n')
        print('3. Informe Revision\n')
        print('4. Porcentaje Calidad\n')
        print('5. Imprimir Informe\n')
        print('6. Leer Informe\n')
        print('7. Regresar menú principal\n')

        opcion = int(input('Elige una opción: '))
        #break
        
    except ValueError:
        print('Oops!  Este número no es válido.  Intenta nuevamente...')

    if opcion == 1:
        consultar_empleados()            
  
    elif opcion == 2:
        consultar_llamadas()

    elif opcion == 3:
        informe_revision()

    elif opcion == 4:
        porcentaje_llamada()
    
    elif opcion == 5:
        with open("C:/Users/lccañon/Desktop/python_G45/revision.txt", "w", encoding="utf") as abrirArchivo:
            print(abrirArchivo.writelines(["INFORME REVISIONES\n", "Alta\n", "Media\n", "Baja\n"]))
            #Se usa encoding para los caracteres especiales
            abrirArchivo=open("C:/Users/lccañon/Desktop/python_G45/revision.txt", "r", encoding="utf")
            #Si no se coloca nada el va a leer, aca se puso la r
            print(abrirArchivo.read())
            #Convertir el archivo en una lista
            print(list(abrirArchivo))
            #Recorrer una lista
        for linea in abrirArchivo:
            print(linea) 
        #Es necesario cerrar el archivo
        abrirArchivo.close()
        main()
    
    elif opcion ==6:
        nombreArchivo=input("Ingrese el nombre del archivo")
        print(leerArchivo(nombreArchivo))
        main()
  
    elif opcion == 7:
        main()

    else:
        print('El valor ingresado no es válido')

def main():

        try:
            print('**********************************\n')
            print('Bienvenidos a la Aerolinea Avizpao ✈\n')
            print('**********************************\n')
            print('1. Ingresar\n')
            print('2. Consultar\n')

            opcion = int(input('Elige una opción: '))

        except ValueError:
            print('Oops!  Este número no es válido.  Intenta nuevamente...')

        if opcion == 1:
            ingresar()            
            main()
            
   
        elif opcion == 2:
            consultar()
            main()

        else:
            print('El valor ingresado no es válido')

if __name__ == '__main__':
    main()