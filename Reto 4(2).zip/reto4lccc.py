#Definición de Listas

lista_pasajeros=[]
cantidad_pasajeros=[]
lista_vuelos=[]
lista_vuelos_mes=[]
lista_vuelos_mes_enero=[]
lista_vuelos_mes_febrero=[]
lista_vuelos_t=[]
lista_vuelos_temporada=[]
ganancia_mes = []

#Definición de Variables

numero_usuarios=0
cantidad_vuelos_mes=0
total_ganancia_ano=0
vuelos_temporada_baja = 0
vuelos_temporada_alta = 0
valor_tiquete_temporada_baja = 50000
valor_tiquete_temporada_alta = 500000

#Definición de Funciones

def cantidad_vuelos (lista):
    vuelos=0
    for j in range(0,len(lista),5):
        for i in range(j,j+5):
                       
            if i == j+4:
                vuelos+=1
    return vuelos


def sumatoria_vuelos (lista):
    if len(lista)==1:
        return lista[0]
                        
    else:
        return lista[0] + sumatoria_vuelos(lista[1:])


def calcular_vuelo_baja ():

    numero_tiquetes = int(input('Número de tiquetes a comprar:'))     
    capacidad_vuelo = 20

    if numero_tiquetes > 5 and numero_tiquetes <=9:
        capacidad_vuelo = capacidad_vuelo - numero_tiquetes           
        valor_total = numero_tiquetes * valor_tiquete_temporada_baja + (valor_tiquete_temporada_baja*1/100)
        ganancia_mes.append(valor_total)

    elif numero_tiquetes >=10:
        capacidad_vuelo = capacidad_vuelo - numero_tiquetes           
        valor_total = numero_tiquetes * valor_tiquete_temporada_baja + (valor_tiquete_temporada_baja*2/100) 
        ganancia_mes.append(valor_total)

    elif numero_tiquetes <=5:
        capacidad_vuelo = capacidad_vuelo - numero_tiquetes           
        valor_total = numero_tiquetes * valor_tiquete_temporada_baja
        ganancia_mes.append(valor_total)

    elif numero_tiquetes  > 20:
        print('Vuelo con cupo completo')
    return


def calcular_vuelo_alta ():

    numero_tiquetes = int(input('Número de tiquetes a comprar:'))     
    capacidad_vuelo = 20

    if numero_tiquetes > 5 and numero_tiquetes <=9:
        capacidad_vuelo = capacidad_vuelo - numero_tiquetes           
        valor_total = numero_tiquetes * valor_tiquete_temporada_alta + (valor_tiquete_temporada_alta*1/100) 
        ganancia_mes.append(valor_total)

    elif numero_tiquetes >=10:
        capacidad_vuelo = capacidad_vuelo - numero_tiquetes           
        valor_total = numero_tiquetes * valor_tiquete_temporada_alta + (valor_tiquete_temporada_alta*2/100) 
        ganancia_mes.append(valor_total)

    elif numero_tiquetes <=5:
        capacidad_vuelo = capacidad_vuelo - numero_tiquetes           
        valor_total = numero_tiquetes * valor_tiquete_temporada_alta
        ganancia_mes.append(valor_total)

    elif numero_tiquetes  > 20:
        print('Vuelo con cupo completo')
    return


def reservar_vuelo():

    print('**********************************\n')  
    print('Posibles Temporadas:')
    print('**********************************\n')      
    print('1. Baja')
    print('2. Alta')    
    opcion_temporada = str(input('Ingrese Temporada: '))
    if opcion_temporada == "1":
        lista_vuelos_t.append("Baja")
    elif opcion_temporada == "2":
        lista_vuelos_t.append("Alta")
    vuelos_temporada_baja=0
    vuelos_temporada_alta=0

    if opcion_temporada == "1":
        vuelos_temporada_baja+=1
        print('**********************************\n')
        print('Posibles Meses:')
        print('**********************************\n') 
        print('1. Enero')
        print('2. Febrero')
        print('3. Marzo')
        print('4. Abril')
        print('5. Mayo')
        print('6. Junio')
        mes_viaje = int(input('Ingrese Mes Viaje: '))
        dia_viaje = int(input('Ingrese Día Viaje: '))                                
              
        if mes_viaje == 1:
            mes_vuelo = ['Enero']
            lista_vuelos_mes.append("Enero")
            lista_vuelos_temporada.append(1)
            calcular_vuelo_baja()
        
        
        elif mes_viaje == 2:                           
            mes_vuelo = ['Febrero']
            lista_vuelos_mes.append("Febrero")
            lista_vuelos_temporada.append(1)
            calcular_vuelo_baja()                   


        elif mes_viaje == 3:
            mes_vuelo = ['Marzo']
            lista_vuelos_mes.append("Marzo")
            lista_vuelos_temporada.append(1)
            calcular_vuelo_baja()
            

        elif mes_viaje == 4:
            mes_vuelo = ['Abril']
            lista_vuelos_mes.append("Abril")
            lista_vuelos_temporada.append(1)
            calcular_vuelo_baja()


        elif mes_viaje == 5:
            mes_vuelo = ['Mayo']
            lista_vuelos_mes.append("Mayo")
            lista_vuelos_temporada.append(1)
            calcular_vuelo_baja()


        elif mes_viaje == 6:
            mes_vuelo = ['Junio']
            lista_vuelos_mes.append("Junio")
            lista_vuelos_temporada.append(1)
            calcular_vuelo_baja()                   
        
    
    else:
        vuelos_temporada_alta+=1
        print('**********************************\n')
        print('Posibles Meses:')
        print('**********************************\n')
        print('7. Julio')
        print('8. Agosto')
        print('9. Septiembre')
        print('10. Octubre')
        print('11. Noviembre')
        print('12. Diciembre')
        mes_viaje = int(input('Ingrese Mes Viaje: '))
        dia_viaje = int(input('Ingrese Día Viaje: '))       
                    

        if mes_viaje == 7:
            mes_vuelo = ['Julio']
            lista_vuelos_mes.append("Julio")
            lista_vuelos_temporada.append(2)
            calcular_vuelo_alta()

        elif mes_viaje ==8:                                  
            mes_vuelo = ['Agosto']
            lista_vuelos_mes.append("Agosto")
            lista_vuelos_temporada.append(2)
            calcular_vuelo_alta()
        
        elif mes_viaje == 9:
            mes_vuelo = ['Septiembre']
            lista_vuelos_mes.append("Septiembre")
            lista_vuelos_temporada.append(2)
            calcular_vuelo_alta()
            
        elif mes_viaje == 10:
            mes_vuelo = ['Octubre']
            lista_vuelos_mes.append("Octubre")
            lista_vuelos_temporada.append(2)
            calcular_vuelo_alta()


        elif mes_viaje == 11:                    
            mes_vuelo = ['Noviembre']
            lista_vuelos_mes.append("Noviembre")
            lista_vuelos_temporada.append(2)
            calcular_vuelo_alta()


        elif mes_viaje == 12:
            mes_vuelo = ['Diciembre']
            lista_vuelos_mes.append("Diciembre")
            lista_vuelos_temporada.append(2)
            calcular_vuelo_alta()
    return


def ingreso_usuario():

        numero_usuarios = 0
        nombre=input("Ingrese Nombre de Pasajero:")
        nombre = nombre.strip()
        nombre = nombre.capitalize()
        edad=input("Ingrese Edad de Pasajero:")
        print('**********************************\n')
        print('Posibles Destinos:')
        print('**********************************\n') 
        print('1. Cartagena')
        print('2. Barranquilla')
        print('3. Santa Marta')
        destino=input("Ingrese Destino Viaje:")
        if destino == "1":
            lista_vuelos.append("Cartagena")
        elif destino == "2":
            lista_vuelos.append("Barranquilla")
        elif destino == "3":
            lista_vuelos.append("Santa Marta")
        reservar_vuelo()
        agregar_usuario =str(input('Desea ingresar otro usuario (SI/NO):'))
        lista_pasajeros.append(nombre)
        lista_pasajeros.append(edad)
        cantidad_pasajeros.append(1)

        if agregar_usuario == 'SI':
            ingreso_usuario()
            numero_usuarios += 1
 
        return  

def consulta_info():

    try:
        print("1. Lista de Pasajeros")
        print("2. Lista de Vuelos")
        print("3. Lista de Vuelos por Temporada",)
        print("4. Lista de Vuelos por Mes")
        print("5. Vuelos por Temporada")
        print("6. Cantidad de Vuelos")
        print("7. Cantidad de Pasajeros")
        print("8. Total o Ganancia por Año")
        print("9. Salir")
        opcion_consulta = int(input('Ingrese Consulta: '))
    except ValueError:
            print('El número no es válido')

    #Recorrido de Listas para Mostrar
    if opcion_consulta == 1:
        print(lista_pasajeros)
        print("Recorrer lista por Indices")
        for x in range(0,len(lista_pasajeros)):
            print(lista_pasajeros[x])
        main()

    elif opcion_consulta == 2:
        print(lista_vuelos)
        print("Recorrer lista por Indices")
        for x in range(0,len(lista_vuelos)):
            print(lista_vuelos[x])
        main()

    elif opcion_consulta == 3:
        print(lista_vuelos_t)
        print("Recorrer lista por Indices")
        for x in range(0,len(lista_vuelos_t)):
            print(lista_vuelos_t[x])
        main()

    elif opcion_consulta == 4:
        print(lista_vuelos_mes)
        print("Enero",lista_vuelos_mes.count("Enero"))
        print("Febrero",lista_vuelos_mes.count("Febrero"))
        print("Marzo",lista_vuelos_mes.count("Marzo"))
        print("Abril",lista_vuelos_mes.count("Abril"))
        print("Mayo",lista_vuelos_mes.count("Mayo"))
        print("Junio",lista_vuelos_mes.count("Junio"))
        print("Julio",lista_vuelos_mes.count("Julio"))
        print("Agosto",lista_vuelos_mes.count("Agosto"))
        print("Septiembre",lista_vuelos_mes.count("Septiembre"))
        print("Octubre",lista_vuelos_mes.count("Octubre"))
        print("Noviembre",lista_vuelos_mes.count("Noviembre"))
        print("Diciembre",lista_vuelos_mes.count("Diciembre"))
        main()

    elif opcion_consulta == 5:
        print("Cantidad de Vuelos Temporada Baja",lista_vuelos_temporada.count(1))
        print("Cantidad de Vuelos Temporada Alta",lista_vuelos_temporada.count(2))
        main()
    
    elif opcion_consulta == 6:
        print(lista_vuelos_temporada.count(1)+lista_vuelos_temporada.count(2))
        main()
    
    elif opcion_consulta == 7:
        print(len(cantidad_pasajeros))
        main()

    elif opcion_consulta == 8:
        print("Dinero Ingresado", ganancia_mes)
        print("Ganancias por año", sum(ganancia_mes))
        main()

#Menu principal
def main():

    try:
        print('**********************************\n')  
        print('Bienvenidos a la Aerolinea Avizpao\n')
        print('**********************************')  
        print('1. Ingresar Nuevo Vuelo\n')
        print('2. Consultar Vuelos\n')
        print('3. Salir\n')
        
        opcion = int(input('Elige una opción: '))

    except ValueError:
            print('El número no es válido')

    if opcion==1:
        ingreso_usuario()
        main()
    
    if opcion==2:
        consulta_info()
        main()

if __name__ == '__main__':
    main()