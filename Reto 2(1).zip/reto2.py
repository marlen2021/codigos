contador=0
respuesta=input("Desea calcular un plan: SI/NO")

while respuesta == "SI":
    contador+1
    valorPlan=input("Ingrese el valor del plan:")
    valorPlan=int(valorPlan)
    numeroCuotas=input("Ingrese la cantidad de cuotas:")
    numeroCuotas=int(numeroCuotas)
    interesPlan=int(5)
    primerDescuento=int(20)
    segundoDescuento=int(10)
    valorCuota=float(valorPlan/numeroCuotas)
    interes=float(valorCuota*5/100)*numeroCuotas
    valorInteres=float(interes*numeroCuotas)

    if numeroCuotas <=2:
        totalPagar = float(valorPlan+valorInteres)
        print("Valor descuento:", "NO TIENE DESCUENTO")

    elif numeroCuotas == 3 or numeroCuotas <= 6:
        descuento=float(valorPlan*primerDescuento/100)
        totalPagar = float(valorPlan+valorInteres-descuento)
        print("Valor descuento:", "{:.2f}".format(descuento))

    elif numeroCuotas >= 7 and numeroCuotas <= 10: 
        descuento=float(valorPlan*segundoDescuento/100)
        totalPagar = float(valorPlan+valorInteres-descuento)
        print("Valor descuento:", "{:.2f}".format(descuento))

    elif numeroCuotas >= 11 and numeroCuotas <= 24:
        totalPagar = float(valorPlan+valorInteres)
        print("Valor descuento:", "NO TIENE DESCUENTO")

    elif numeroCuotas > 24:
        print("El numero de cuota es mayor a 24, el sistema no puede calcular el Plan")


    print("Valor del plan:", valorPlan)
    print("Valor de la cuota:", "{:.2f}".format(valorCuota))
    print("Numero de cuotas:", numeroCuotas)
    print("Valor intereses:", "{:.2f}".format(valorInteres))
    print("Total a pagar:", "{:.2f}".format(totalPagar))
    respuesta=input("Desea calcular un plan: SI/NO")









