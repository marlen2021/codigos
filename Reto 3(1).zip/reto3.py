nombre=["Elber","Edwin","Juliana","Ernesto","Felipe","Humberto","Giovanni","Luis","Laura","Camila","Johanna","Sofia","Omar","Laura","Johanna","Stella","Mario","Luis","Luis","Marcos"]
edad=[20,78,96,23,14,78,25,46,32,52,26,28,24,16,53,47,48,41,43,46]
cedula=[25741896,1254789630,5102354,98523654,60147852,30265874,28014562,14256369,10236547,7854123,9874215,3214569,985741,1236985,1478526,9874562,1326547,4569812,1265458,201475]           
fecha=["23/04/2019", "28/03/2019", "21/06/2019", "20/05/2019", "19/08/2019", "19/03/2019","21/06/2019","20/05/2019","18/07/2019", "31/12/2019", "01/11/2019", "01/04/2019","04/03/2019", "21/06/2019", "20/05/2019","19/03/2019", "21/06/2019", "20/05/2019","19/03/2019", "03/09/2019"]
genero=["M","M","F","M","M","M","M","M","F","F","F","F","M","F","F","F","M","M","M","M"]


print("Bienvenido a SanosyFelices")
try:
    ingreso=str(input("Desea Ingresar al Sistema: (si/no) \n "))
except ValueError:
    print("\n Error al digitar no lleva espacio y todo en minuscula")


while ingreso=="si":
    try:
        vas_a_vacunar=str(input("Desea Vacunarse: (si/no)\n"))        
    except ValueError:
        print("\n Error al digitar no lleva espacio y todo en minuscula")
                                                                                             
    pacientes_sin_vacunar=0
    if pacientes_sin_vacunar=="no":
        pacientes_sin_vacunar+=1
        
    elif vas_a_vacunar=="si":
           
            primera_vez=str(input("¿Ya te has aplicado alguna vacuna?: (si/no)\n"))
        
            nuevos_pacientes=[]

            if primera_vez == "no":
                            
                try:
                    nuevos=str(input("Ingrese el nombre\n  "))
                    Cedula=int(input("Ingrese numero de cedula\n  "))
                    Edad=int(input("Ingrese su edad\n "))
                    Fecha=str(input("Ingrese fecha de la vacunacion (DD/MM/AAAA)\n"))
                    sexo=str(input("Ingrese el sexo (M/F)\n "))
                    cedula.append(Cedula)
                    nombre.append(nuevos)
                    nuevos_pacientes.append(nuevos)
                    edad.append(Edad)
                    fecha.append(Fecha)
                    genero.append(sexo)
                except ValueError:
                    print ("Error verifique que los datos personales sean los solicitados")
            elif primera_vez=="si":
                pass
    
    pacientes_covid=0
    covid=str(input("¿Ha tenido covid?: (si/no)\n"))
    if covid == "si":
        pacientes_covid+=1

        print("Cual vacuna se  desea aplicar:  ")
        print("1 Pfizer")
        print("2 Moderna")
        print("3 AstraZeneca")
        try:
            vacuna=int(input("Ingrese la seleccion\n"))
        except ValueError:
            print ("/n Error no es una seleccion valida")

        Pfizer=0
        if vacuna == 1:
            Pfizer+=1

        Moderna=0
        if vacuna == 2:
            Moderna+=1

        AstraZeneca=0
        if vacuna == 3:
            AstraZeneca+=1

    try:
        siguiente_registro=str(input("Desea registrar otro paciente: (si/no)\n"))
        if siguiente_registro=="si":
            continue
        else:
            break
    except ValueError:
        print("Ingrese la respuesta sin espacios y en minuscula")


pacientes_repetidos={}
for n in nombre:
    if n in pacientes_repetidos:
        pacientes_repetidos[n]+=1
    else:
        pacientes_repetidos[n]=1

lista=[]
menu_principal=int(input("Menu Principal SanosyFelices  \n 1- Lista de pacientes vacunados  \n 2- Numero de pacientes que rechazaron o no quieren la vacuna  \n 3- Cantidad de pacientes repetidos  \n 4- Ultimos pacientes agregados  \n 5- Pacientes reemplazados  \n 6- Vacunados con Pfizer  \n 7- Vacunados con Moderna  \n 8- Vacunados con AstraZeneca  \n 9- Numero se pacientes con COVD previo a la vacunacion \n 0- Salir\n"))

while menu_principal !=0:
    
    if menu_principal==1:
        print("Lista de Pacientes Vacunados \n")
        print("Nombre  Cedula   Edad  Sexo  Fecha de vacunacion")
        for i in range(len(nombre)):
            if i not in lista:
                print(nombre[i],"   ",cedula[i]," ",edad[i],"     ",genero[i],"         ",fecha[i])
            
    elif menu_principal == 2:
        print("Numeros de pacientes que rechazaron la vacuna:  ",pacientes_sin_vacunar)
    
    elif menu_principal == 3:
        repetidos={}
        for valor in nombre:
            if n in repetidos:
                repetidos[valor]+=1
            else:
                repetidos[valor]=1
        print("Numeros de pacientes repetidos son:  ",len(repetidos))

    elif menu_principal == 4:
        print(f"Los ultimos pacientes agregados son: \n {nuevos_pacientes}" )

    elif menu_principal == 6:
        print("Cantidad de vacunas Pfizer usadas: \n",Pfizer)

    elif menu_principal == 7:
        print("Cantidad de vacunas Moderna usadas: \n",Moderna)

    elif menu_principal == 8:
        print("Cantidad de vacunas AstraZeneca usadas: \n" ,AstraZeneca)

    elif menu_principal == 9:
        print("Numero de pacientescon COVID antes de la vacunacion",pacientes_covid)

    else:
        print("Esa opcion no es valida\n Ingrese una opcion:")

    menu_principal=int(input("Menu Principal SanosyFelices \n 1- Lista de pacientes vacunados  \n 2- Numero de pacientes que rechazaron o no quieren la vacuna  \n 3-Cantidad de pacientes repetidos  \n 4- Ultimos pacientes agregados  \n 5- Pacientes reemplazados  \n 6-Vacunados con Pfizer  \n 7- Vacunados con Moderna  \n 8- Vacunados con AstraZeneca  \n 9-Numero se pacientes con COVD previo a la vacunacion \n 0- salir\n"))