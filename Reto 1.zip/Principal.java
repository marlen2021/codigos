/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mycompany.reto1;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author lccañon
 */
public class Principal {

    public static Scanner entrada=new Scanner(System.in);
    //Declaración de variables 
    public static int capacidaVuelo=20;
    public static int vuelostb=0;
    public static int vuelosta=0;
    public static int vuelose=0;
    public static int vuelosf=0;
    public static int vuelosm=0;
    public static int vuelosa=0;
    public static int vuelosma=0;
    public static int vuelosjn=0;
    public static int vuelosjl=0;
    public static int vuelosago=0;
    public static int vueloss=0;
    public static int vueloso=0;
    public static int vuelosn=0;
    public static int vuelosd=0;
    public static int valorTotalImpresion=0;
    //Declaración de Arreglos
    public static String [] nombrePasajero;
    public static String [] edadPasajero;
    public static String [] vueloPasajero;
    public static String [] temporadaPasajero;
    public static String [] mesBajaPasajero;
    public static String [] mesAltaPasajero;
    
    //Metodo principal
    public static void main(String[] args) {
        
        String opcion="";
        
        while (!opcion.equals("3")) {
            menuPrincipal();
            System.out.println("Seleccione una opción:");
            opcion=entrada.nextLine();
            switch (opcion) {
                case "1":
                    ingresoVuelo();
                    System.out.println("¿Desea registrar otro vuelo? \n1. si\n2. no");
                    opcion=entrada.nextLine();
                    if (opcion.equals("1")) {
                        ingresoVuelo();
                    } else if (opcion.equals("2")) {
                        break;
                    } else {
                        System.out.println("No se ha ingresado una opcion valida, oprima una tecla para continuar.");
                    }
                    break;
                case "2":
                    System.out.println("Menu Consulta");
                    menuConsultas();
                    break;
                case "3":
                    break;
                default:
                    System.out.println("No se ha ingresado una opci{on valida, oprima una tecla para continuar.");
                    break;
            }
        }
        
        entrada.close();
    }
    
    public static void menuPrincipal(){
        
        System.out.println("\n Bienvenidos a la Aerolinea el Avizpao \n");
        System.out.println("1. Ingresar vuelo");
        System.out.println("2. Menu de consultas");
        System.out.println("3. Salir");
      
    }
    
    //Metodo para impresión de arreglos
    static void arrayImpresion(String[] array){
        for (String value:array){
            System.out.println(value);
        }
    }
    
    //Metodo para el menu de consultas
    public static void menuConsultas(){
        
        String opcion="";
        System.out.println("1. Lista de Pasajeros");
        System.out.println("2. Lista de Vuelos");
        System.out.println("3. Lista de Vuelos por Mes");
        System.out.println("4. Lista de Vuelos por Temporada");
        System.out.println("5. Cantidad de Vuelos");
        System.out.println("6. Total o Ganancia por Año");
        System.out.println("7. Salir");
         while (!opcion.equals("7")) {
            System.out.println("Seleccione una opción:");
            opcion=entrada.nextLine();
            //Condicional para el ingreso por teclado
            switch (opcion) {
                case "1":
                    System.out.println("Los pasajeros son:");
                    arrayImpresion(nombrePasajero);
                    break;
                case "2":
                    System.out.print("Los vuelos ingresados son: ");
                    arrayImpresion(vueloPasajero);
                    break;
                case "3":
                    System.out.println("Los vuelos por mes ingresados son:");
                    System.out.println("Enero: "+vuelose);
                    System.out.println("Febrero: "+vuelosf);
                    System.out.println("Marzo: "+vuelosm);
                    System.out.println("Abril: "+vuelosa);
                    System.out.println("Mayo: "+vuelosma);
                    System.out.println("Junio: "+vuelosjn);
                    System.out.println("Julio: "+vuelosjl);
                    System.out.println("Agosto: "+vuelosago);
                    System.out.println("Septiembre: "+vueloss);
                    System.out.println("Octubre: "+vueloso);
                    System.out.println("Noviembre: "+vuelosn);
                    System.out.println("Diciembre: "+vuelosd);
                    break;
                case "4":
                    System.out.println("Los vuelos por temporada ingresados son:");
                    System.out.println("Alta: "+vuelosta);
                    System.out.println("Baja: "+vuelostb);
                    break;
                case "5":
                    System.out.println("La cantidad de vuelos es: "+(vuelosta+vuelostb));
                    break;
                case "6":
                    System.out.println("Total o Ganancia por año es: "+valorTotalImpresion);
                    break;
                case "7":
                    break;
                default:
                    System.out.println("No se ha ingresado una opción valida, oprima una tecla para continuar.");
                    break;
            }
        }        
    }
    
    //Metodo para el ingreso de vuelo
    public static void ingresoVuelo(){
        String destino="";
        System.out.println("Ingrese la cantidad de pasajeros a registrar");
        String vuelos=entrada.nextLine();
        int nVuelos = Integer.parseInt(vuelos);
        nombrePasajero=new String[nVuelos];
        edadPasajero=new String[nVuelos];
        
        for(int i=0; i<nVuelos;i++){
            System.out.println((i+1)+"Ingrese nombre de pasajero");
            nombrePasajero[i]=entrada.next();   
            System.out.println((i+1)+"Ingrese edad de pasajero");
            edadPasajero[i]=entrada.next();   
        }
        
        vueloPasajero = new String[]{vuelos}; 
        
        System.out.println("'**********************************\n");
        System.out.println("Posibles Destinos:");
        System.out.println("'**********************************\n"); 
        System.out.println("1. Cartagena");
        System.out.println("2. Barranquilla");
        System.out.println("3. Santa Marta");
        System.out.println("Ingrese Destino viaje:");
        entrada.nextLine();
        destino=entrada.nextLine();
        reservarVuelo();
          
    }
    
    //Metodo para la reserva del vuelo
    public static void reservarVuelo(){
        
        String temporada="";
        String temporada2="";
        String mes="";
        String opcion="";
        String opcion2="";
        String opcion3="";
        System.out.println("**********************************\n");  
        System.out.println("Posibles Temporadas:");
        System.out.println("**********************************\n");      
        System.out.println("1. Baja");
        System.out.println("2. Alta");
        System.out.println("Seleccione una opción:");
        temporada=entrada.nextLine();
        if(temporada == "1")
        {
            opcion = "Baja";
        }
        else
        {
            opcion = "Alta";
        }
        
        temporadaPasajero = new String[]{opcion}; 
       
        if(temporada.equals("1")){
            vuelostb+=1;
            System.out.println("Selecciona Baja");
            System.out.println("**********************************\n");
            System.out.println("Posibles Meses:");
            System.out.println("**********************************\n");
            System.out.println("1. Enero");
            System.out.println("2. Febrero");
            System.out.println("3. Marzo");
            System.out.println("4. Abril");
            System.out.println("5. Mayo");
            System.out.println("6. Junio");
            System.out.println("Seleccione una opción:");
            mes=entrada.nextLine();
            if(mes.equals("1")){
                opcion2 = "Enero";
                vuelose+=1;
            }
            if(mes.equals("2")){
                opcion2 = "Febrero";
                vuelosf+=1;
            }
            if(mes.equals("3")){
                opcion2 = "Marzo";
                vuelosm+=1;
            }
            if(mes.equals("4")){
                opcion2 = "Abril";
                vuelosa+=1;
            }
            if(mes.equals("5")){
                opcion2 = "Mayo";
                vuelosma+=1;
            }
            if(mes.equals("6")){
                opcion2 = "Junio";
                vuelosjn+=1;
            }
            
            mesBajaPasajero = new String[]{mes}; 
            System.out.println("Ingrese el No de Tiquetes:");
            String tiquete=entrada.nextLine();
            int nTiquetes = Integer.parseInt(tiquete);
            calcularVueloBaja(nTiquetes);
            
        }
        
        else{
            vuelosta+=1;
            System.out.println("Selecciona Alta");
            System.out.println("**********************************\n");
            System.out.println("Posibles Meses:");
            System.out.println("**********************************\n");
            System.out.println("7. Julio");
            System.out.println("8. Agosto");
            System.out.println("9. Septiembre");
            System.out.println("10. Octubre");
            System.out.println("11. Noviembre");
            System.out.println("12. Diciembre");
            System.out.println("Seleccione una opción:");
            temporada2=entrada.nextLine();
            if(temporada2.equals("7")){
                opcion3 = "Julio";
                vuelosjl+=1;
            }
            if(temporada2.equals("8")){
                opcion3 = "Agosto";
                vuelosago+=1;
            }
            if(temporada2.equals("9")){
                opcion3 = "Septiembte";
                vueloss+=1;
            }
            if(temporada2.equals("10")){
                opcion3 = "Octubre";
                vueloso+=1;
            }
            if(temporada2.equals("11")){
                opcion3 = "Noviembre";
                vuelosn+=1;
            }
            if(temporada2.equals("12")){
                opcion3 = "Diciembre";
                vuelosd+=1;
            }
            mesAltaPasajero = new String[]{temporada2}; 
            System.out.println("Ingrese el No de Tiquetes:");
            String tiquete=entrada.nextLine();
            int nTiquetes = Integer.parseInt(tiquete);
            calcularVueloAlta(nTiquetes);
        }
    }
    
    //Metodo para el calculo de tiquetes en temporada baja
     public static void calcularVueloBaja(int nTiquetes){
       
          int valorTotal=0;
          int valorTiquete=50000;
        
            if (nTiquetes > 5 && nTiquetes <=9){
             capacidaVuelo = capacidaVuelo - nTiquetes;
             valorTotal = nTiquetes * valorTiquete + (valorTiquete*1/100);
            }
            else if(nTiquetes >= 10){
             capacidaVuelo = capacidaVuelo - nTiquetes;
             valorTotal = nTiquetes * valorTiquete + (valorTiquete*2/100);
                
            }
            else if(nTiquetes <= 5){
             capacidaVuelo = capacidaVuelo - nTiquetes;
             valorTotal = nTiquetes * valorTiquete;
            }
            else if(nTiquetes > 20){
                System.out.println("Vuelo con cupo completo");
            }
         valorTotalImpresion+=valorTotal;
     }
     
     
     //Metodo para el calculo de tiquetes en temporada alta
     public static void calcularVueloAlta(int nTiquetes){
 
          int valorTotal=0;
          int valorTiquete=500000;
          
          System.out.println("Ingrese la cantidad de tiquetes a comprar:");
            if (nTiquetes > 5 && nTiquetes <=9){
             capacidaVuelo = capacidaVuelo - nTiquetes;
             valorTotal = nTiquetes * valorTiquete + (valorTiquete*1/100);
             
            }
            else if(nTiquetes >= 10){
             capacidaVuelo = capacidaVuelo - nTiquetes;
             valorTotal = nTiquetes * valorTiquete + (valorTiquete*2/100);
                
            }
            else if(nTiquetes <= 5){
             capacidaVuelo = capacidaVuelo - nTiquetes;
             valorTotal = nTiquetes * valorTiquete;
            }
            else if(nTiquetes > 20){
                System.out.println("Vuelo con cupo completo");
            }
            
          valorTotalImpresion+=valorTotal;
      
     }
     
}